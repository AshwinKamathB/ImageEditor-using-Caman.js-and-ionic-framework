(function () {
    'use strict';

    angular.module('imageEditor').controller('imageCtrl', ['$state', imageEditor]);

    function imageEditor($state) {
       
        var vm = this; 

        vm.ChangeBrightness = function(){

          console.log("Brightness",vm.brightness);

           Caman('#canvas',  function() {
             this.revert(false);
              this.brightness(vm.brightness).render();
            });
        }

        vm.ChangeContrast = function(){

          console.log("Contrast",vm.contrast);

          Caman('#canvas',  function() {
               this.revert(false);
              this.contrast(vm.contrast).render();
            });
        }

        vm.brightness=0;
        vm.contrast=0;  
              
    };
})();